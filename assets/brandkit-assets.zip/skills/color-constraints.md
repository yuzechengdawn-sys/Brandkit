# Color constraints (placeholder)

> Demo content only. This file will be replaced by the published BrandKit rule package.

## Scope

- Read semantic color names before using raw values.
- Use one approved theme in a single asset.
- Keep text and background combinations readable.
- Do not create unapproved gradients or replacement colors.

## Source

- Guide: Color
- Brand package: v1.2 demo
