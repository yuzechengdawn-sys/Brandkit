# Basic constraints (placeholder)

> Demo content only. This file will be replaced by the published BrandKit rule package.

## Scope

- Use approved logo assets only.
- Preserve the original aspect ratio.
- Keep the clear space shown in the Guide.
- Do not use the logo below the published minimum size.
- Use only approved logo color variants.

## Source

- Guide: Basic
- Brand package: v1.2 demo
