# Grid constraints (placeholder)

> Demo content only. This file will be replaced by the published BrandKit rule package.

## Scope

- Place text, subject and atmosphere inside their approved zones.
- Keep key information inside the safe area.
- Use whole grid columns for modules.
- Apply the documented fallback when copy becomes too long.

## Source

- Guide: Grid
- Brand package: v1.2 demo
